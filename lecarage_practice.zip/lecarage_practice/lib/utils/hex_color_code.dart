int hexColors(String colors) {
  // ignore: prefer_interpolation_to_compose_strings
  String sColors = '0xff' + colors;
  sColors = sColors.replaceAll("#", '');
  int dColors = int.parse(sColors);
  return dColors;
}
