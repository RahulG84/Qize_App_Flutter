class MyRoutes {
  static String loginRoute = "/login";
  static String signupRoute = "/signup";
  static String homeRoute = "/home";
  static String firstPageRoute = "/firstPage";
  static String secondPageRoute = "/secondPage";
  static String thirdPageRoute = "/thirdPage";
}